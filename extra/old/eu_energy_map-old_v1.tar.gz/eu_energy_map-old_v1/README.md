# EU-Energy-Map
Dashboard visualizing Eurostat data regarding renewable energy developments in the European Union.  

## Screenshot
![webapp-screenshot.png](https://raw.githubusercontent.com/kuranez/EU-Energy-Map/refs/heads/main/screenshots/webapp-screenshot.png)
