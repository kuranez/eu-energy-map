import panel as pn
pn.extension('tabulator', 'plotly', design='material', sizing_mode='stretch_width')

MAPBOX_TOKEN = 'your_mapbox_token'